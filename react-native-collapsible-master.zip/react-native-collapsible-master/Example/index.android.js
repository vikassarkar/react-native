import { AppRegistry } from 'react-native';
import ExampleView from './app';

AppRegistry.registerComponent('Example', () => ExampleView);
